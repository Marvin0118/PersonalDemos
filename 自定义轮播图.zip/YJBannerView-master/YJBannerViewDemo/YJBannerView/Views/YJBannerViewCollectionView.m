//
//  YJBannerViewCollectionView.m
//  YJBannerViewDemo
//
//  Created by YJHou on 2017/11/21.
//  Copyright © 2017年 Address:https://github.com/stackhou . All rights reserved.
//

#import "YJBannerViewCollectionView.h"

@implementation YJBannerViewCollectionView

@end

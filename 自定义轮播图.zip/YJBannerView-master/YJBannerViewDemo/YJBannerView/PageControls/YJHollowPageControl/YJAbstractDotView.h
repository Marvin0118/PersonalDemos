//
//  YJAbstractDotView.h
//  YJBannerViewDemo
//
//  Created by YJHou on 2015/5/24.
//  Copyright © Address:https://github.com/stackhou . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YJAbstractDotView : UIView

- (void)changeActivityState:(BOOL)active;

@end

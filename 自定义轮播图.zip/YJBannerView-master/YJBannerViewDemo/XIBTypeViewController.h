//
//  XIBTypeViewController.h
//  YJBannerViewDemo
//
//  Created by YJHou on 2018/3/26.
//  Copyright © 2018年 Address:https://github.com/stackhou  . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XIBTypeViewController : UIViewController

@end

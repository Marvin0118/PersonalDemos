//
//  DynamicBgViewController.h
//  YJBannerViewDemo
//
//  Created by YJHou on 2017/11/7.
//  Copyright © 2017年 Address:https://github.com/stackhou . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DynamicBgViewController : UIViewController

@end

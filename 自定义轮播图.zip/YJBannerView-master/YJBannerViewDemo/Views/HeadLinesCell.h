//
//  HeadLinesCell.h
//  YJBannerViewDemo
//
//  Created by YJHou on 2017/7/4.
//  Copyright © 2017年 Address:https://github.com/stackhou . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeadLinesCell : UICollectionViewCell

- (void)cellWithHeadHotLineCellData:(NSString *)string;

@end

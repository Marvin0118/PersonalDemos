//
//  YJCustomGapCell.h
//  YJBannerViewDemo
//
//  Created by YJHou on 2018/1/12.
//  Copyright © 2018年 Address:https://github.com/stackhou  . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YJCustomGapCell : UICollectionViewCell

- (void)cellWithImagePath:(NSString *)imagePath;

@end

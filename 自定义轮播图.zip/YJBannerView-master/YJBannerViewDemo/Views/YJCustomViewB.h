//
//  YJCustomViewB.h
//  YJBannerViewDemo
//
//  Created by YJHou on 2018/1/9.
//  Copyright © 2018年 Address:https://github.com/stackhou  . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YJCustomViewB : UICollectionViewCell

@end

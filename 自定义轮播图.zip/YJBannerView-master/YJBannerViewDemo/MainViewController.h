//
//  MainViewController.h
//  YJBannerViewDemo
//
//  Created by YJHou on 2014/5/24.
//  Copyright © 2014年 Address:https://github.com/stackhou . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController

@end

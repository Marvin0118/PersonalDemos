//
//  YJBannerViewFramework.h
//  YJBannerViewFramework
//
//  Created by YJHou on 2017/7/3.
//  Copyright © 2017年 Address:https://github.com/stackhou . All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for YJBannerViewFramework.
FOUNDATION_EXPORT double YJBannerViewFrameworkVersionNumber;

//! Project version string for YJBannerViewFramework.
FOUNDATION_EXPORT const unsigned char YJBannerViewFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <YJBannerViewFramework/PublicHeader.h>



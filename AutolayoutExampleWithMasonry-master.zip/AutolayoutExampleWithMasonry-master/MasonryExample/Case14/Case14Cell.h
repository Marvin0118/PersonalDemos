//
//  Case14Cell.h
//  MasonryExample
//
//  Created by tutuge on 2017/3/12.
//  Copyright © 2017年 tutuge. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Case14StairView.h"

@interface Case14Cell : UITableViewCell
@property (nonatomic, strong) Case14StairView *stairView;
@end

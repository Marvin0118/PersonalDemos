//
// Created by zorro on 15/12/5.
// Copyright (c) 2015 tutuge. All rights reserved.
//

#import "Case8DataEntity.h"

@implementation Case8DataEntity
@end
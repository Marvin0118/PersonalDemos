//
//  Case13TableViewCell.h
//  MasonryExample
//
//  Created by tutuge on 2016/11/6.
//  Copyright © 2016年 tutuge. All rights reserved.
//

#import <UIKit/UIKit.h>

static NSString *kCase13TableViewCellIdentifier = @"Case13TableViewCell";

@interface Case13TableViewCell : UITableViewCell

- (void)configWithTexts:(NSArray <NSString *> *)cellTexts;

@end

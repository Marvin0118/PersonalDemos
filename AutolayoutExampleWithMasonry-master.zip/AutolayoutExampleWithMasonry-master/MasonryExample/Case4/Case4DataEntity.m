//
//  Case4DataEntity.m
//  MasonryExample
//
//  Created by zorro on 15/7/31.
//  Copyright (c) 2015年 tutuge. All rights reserved.
//

#import "Case4DataEntity.h"

@implementation Case4DataEntity
@end

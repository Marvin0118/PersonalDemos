//
//  Case4Cell.h
//  MasonryExample
//
//  Created by zorro on 15/7/31.
//  Copyright (c) 2015年 tutuge. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Case4DataEntity;

@interface Case4Cell : UITableViewCell

- (void)setupData:(Case4DataEntity *)dataEntity;

@end

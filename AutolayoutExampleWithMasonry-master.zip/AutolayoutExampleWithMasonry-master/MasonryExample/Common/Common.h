//
// Created by zorro on 15/12/5.
// Copyright (c) 2015 tutuge. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Common : NSObject
+ (NSString *)getText:(NSString *)text withRepeat:(int)repeat;
@end
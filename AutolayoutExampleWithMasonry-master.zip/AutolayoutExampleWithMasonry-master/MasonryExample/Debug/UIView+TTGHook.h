//
// Created by zorro on 15/12/28.
// Copyright (c) 2015 tutuge. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UIView (TTGHook)
@end
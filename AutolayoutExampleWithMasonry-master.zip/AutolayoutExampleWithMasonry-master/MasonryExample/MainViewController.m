//
//  MainViewController.m
//  MasonryExample
//
//  Created by zorro on 15/11/29.
//  Copyright © 2015年 tutuge. All rights reserved.
//

#import "MainViewController.h"

@interface MainViewController ()

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"有趣的Autolayout示例-Masonry实现";
}

@end

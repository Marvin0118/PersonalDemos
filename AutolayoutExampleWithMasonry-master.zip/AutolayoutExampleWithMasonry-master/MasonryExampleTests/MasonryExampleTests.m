//
//  MasonryExampleTests.m
//  MasonryExampleTests
//
//  Created by zorro on 15/5/13.
//  Copyright (c) 2015年 tutuge. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <XCTest/XCTest.h>

@interface MasonryExampleTests : XCTestCase

@end

@implementation MasonryExampleTests

- (void)setUp {
    [super setUp];
}

- (void)tearDown {
    [super tearDown];
}

- (void)testExample {
    XCTAssert(YES, @"Pass");
}

@end

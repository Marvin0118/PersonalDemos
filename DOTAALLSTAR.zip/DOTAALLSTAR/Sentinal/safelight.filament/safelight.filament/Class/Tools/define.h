//
//  define.h
//  SafeDarkVC
//
//  Created by M on 16/6/19.
//  Copyright © 2016年 leqi. All rights reserved.
//

#import "TaskRequest.h"
#import "Sign.h"


#ifndef define_h
#define define_h




#define X_App_Key @"X-App-Key"
#define X_App_Signature @"X-App-Signature"
#define X_Timestamp @"X-Timestamp"


#endif /* define_h */

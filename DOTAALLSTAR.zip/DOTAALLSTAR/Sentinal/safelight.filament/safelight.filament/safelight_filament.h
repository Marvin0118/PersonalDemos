//
//  safelight_filament.h
//  safelight.filament
//
//  Created by MBP on 16/7/15.
//  Copyright © 2016年 leqi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JYNetwork.h"
#import "JYGrade.h"
@interface safelight_filament : NSObject

@end

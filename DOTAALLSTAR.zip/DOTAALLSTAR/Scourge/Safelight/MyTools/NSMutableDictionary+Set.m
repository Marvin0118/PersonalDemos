//
//  NSMutableDictionary+Set.m
//  SafeLight
//
//  Created by jackSun on 16/5/30.
//  Copyright © 2016年 junyu. All rights reserved.
//

#import "NSMutableDictionary+Set.h"

@implementation NSMutableDictionary (Set)
- (void)setValue:(int)value forkey:(NSString *)key {
    [self setValue:value forkey:key];
}
@end

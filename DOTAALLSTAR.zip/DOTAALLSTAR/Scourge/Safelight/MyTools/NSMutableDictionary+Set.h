//
//  NSMutableDictionary+Set.h
//  SafeLight
//
//  Created by jackSun on 16/5/30.
//  Copyright © 2016年 junyu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableDictionary (Set)
- (void)setValue: (int)value forkey: (NSString *)key;
@end

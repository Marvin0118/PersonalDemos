//
//  NSDictionary+Get.h
//  SafeLight
//
//  Created by jackSun on 16/5/30.
//  Copyright © 2016年 junyu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Get)
- (int)intValueForKey:(NSString *)key;
@end

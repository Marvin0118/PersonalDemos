//
//  main.m
//  HudDemoTV
//
//  Created by Matej Bukovinski on 17. 07. 16.
//  Copyright © 2016 Matej Bukovinski. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBHudDemoTVAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MBHudDemoTVAppDelegate class]));
    }
}

//
//  RCDGiftDanmakuView.m
//  DanMuDemo
//
//  Created by Sin on 16/11/1.
//  Copyright © 2016年 Sin. All rights reserved.
//

#import "RCDGiftDanmakuView.h"

@implementation RCDGiftDanmakuView

+ (instancetype)giftDanmakuViewWithText:(NSString *)text withImageName:(NSString *)imageName {
    return [[self alloc] initWithText:text withImageName:imageName];
}

- (instancetype)initWithText:(NSString *)text withImageName:(NSString *)imageName {
    self = [super init];
    if(self){
        UILabel *label = [[UILabel alloc]init];
        label.text = text;
        [label sizeToFit];
        label.backgroundColor = [UIColor clearColor];
        UIImageView *imgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:imageName]];
        CGRect labelFrame = label.frame;
        CGRect imageFrame = imgView.frame;
        CGSize selfSize = CGSizeMake(labelFrame.size.width+imageFrame.size.width, imageFrame.size.height);
        imageFrame.origin.x = labelFrame.origin.x+labelFrame.size.width;
        imageFrame.origin.y = labelFrame.origin.y+labelFrame.size.height - imageFrame.size.height;
        imgView.frame = imageFrame;
        self.bounds = CGRectMake(0, 0, selfSize.width, selfSize.height);
        [self addSubview:label];
        [self addSubview:imgView];
    }
    return self;
}

@end

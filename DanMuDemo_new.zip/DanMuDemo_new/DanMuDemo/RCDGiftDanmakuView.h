//
//  RCDGiftDanmakuView.h
//  DanMuDemo
//
//  Created by Sin on 16/11/1.
//  Copyright © 2016年 Sin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RCDGiftDanmakuView : UIView
+ (instancetype)giftDanmakuViewWithText:(NSString *)text withImageName:(NSString *)imageName;
@end

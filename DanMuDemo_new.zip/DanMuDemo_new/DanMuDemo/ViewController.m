//
//  ViewController.m
//  DanMuDemo
//
//  Created by Sin on 16/9/23.
//  Copyright © 2016年 Sin. All rights reserved.
//

#import "ViewController.h"
#import "UIView+RCDDanmaku.h"
#import "RCDDanmaku.h"
#import "RCDDanmakuManager.h"
#import "RCDGiftDanmakuView.h"

#define kRandomColor [UIColor colorWithRed:arc4random_uniform(256) / 255.0 green:arc4random_uniform(256) / 255.0 blue:arc4random_uniform(256) / 255.0 alpha:1]

@interface ViewController ()
@property (nonatomic,assign) NSInteger total;
@property (nonatomic,strong) NSTimer *timer;
@property (nonatomic,strong) UILabel *tipLabel;
@property (nonatomic,assign) BOOL hasEnterBackground;
@property (nonatomic,strong) UISwitch *switchBtn;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationEnterBackground) name: UIApplicationDidEnterBackgroundNotification object:nil];

    UISwitch *switchBtn = [[UISwitch alloc]initWithFrame:CGRectMake(100, 60, 50, 44)];
    [switchBtn addTarget:self action:@selector(changed:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:switchBtn];
    self.switchBtn = switchBtn;
    UILabel *tipLabel = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(switchBtn.frame), 60, 50, 44)];
    self.tipLabel = tipLabel;
    tipLabel.text = @"是否允许弹幕过量加载:否";
    tipLabel.font = [UIFont systemFontOfSize:12];
    [tipLabel sizeToFit];
    [self.view addSubview:tipLabel];
    
    
    UIButton *startButton = [[UIButton alloc]initWithFrame:CGRectMake(100, 100, 60, 44)];
    startButton.backgroundColor = [UIColor greenColor];
    [startButton addTarget:self action:@selector(startDanmaku) forControlEvents:UIControlEventTouchUpInside];
    [startButton setTitle:@"开始" forState:UIControlStateNormal];
    startButton.titleLabel.font = [UIFont systemFontOfSize:15];
    [self.view addSubview:startButton];
    
    UIButton *stopButton = [[UIButton alloc]initWithFrame:CGRectMake(200, 100, 60, 44)];
    stopButton.backgroundColor = [UIColor greenColor];
    [stopButton addTarget:self action:@selector(stopDanmaku) forControlEvents:UIControlEventTouchUpInside];
    [stopButton setTitle:@"停止" forState:UIControlStateNormal];
    stopButton.titleLabel.font = [UIFont systemFontOfSize:15];
    [self.view addSubview:stopButton];
    
    UIButton *pauseButton = [[UIButton alloc]initWithFrame:CGRectMake(100, 160, 60, 44)];
    pauseButton.backgroundColor = [UIColor greenColor];
    [pauseButton addTarget:self action:@selector(pauseDanmaku) forControlEvents:UIControlEventTouchUpInside];
    [pauseButton setTitle:@"暂停" forState:UIControlStateNormal];
    pauseButton.titleLabel.font = [UIFont systemFontOfSize:15];
    [self.view addSubview:pauseButton];
    
    UIButton *resumeButton = [[UIButton alloc]initWithFrame:CGRectMake(200, 160, 60, 44)];
    resumeButton.backgroundColor = [UIColor greenColor];
    [resumeButton addTarget:self action:@selector(resumeDanmaku) forControlEvents:UIControlEventTouchUpInside];
    [resumeButton setTitle:@"重开" forState:UIControlStateNormal];
    resumeButton.titleLabel.font = [UIFont systemFontOfSize:15];
    [self.view addSubview:resumeButton];
    
    self.total = 0;
}
/**
 *  暂停弹幕
 */
- (void)pauseDanmaku {
    [self.view pauseDanmaku];
}
/**
 *  重开弹幕
 */
- (void)resumeDanmaku {
    [self.view resumeDanmaku];
}

- (void)applicationEnterBackground {
    [self.view stopDanmaku];
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.hasEnterBackground = NO;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.view stopDanmaku];
    
}

- (void)changed:(UISwitch *)switchBtn {
    RCDanmakuManager.isAllowOverLoad = switchBtn.on;
    self.tipLabel.text = [NSString stringWithFormat:@"是否允许弹幕过量加载:%@",switchBtn.on?@"是":@"否"];
}


- (void)startDanmaku {
    RCDanmakuManager.isAllowOverLoad = self.switchBtn.on;
    //设置定时器，模仿直播聊天室里观众的发言
    if(!self.timer) {
        NSInteger danmakuCount = 100;//每秒发送的弹幕个数
        self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0/danmakuCount target:self selector:@selector(sendDanmaku) userInfo:nil repeats:YES];
    }
    
}

- (void)stopDanmaku {
    [self.timer invalidate];
    self.timer = nil;
    [self.view stopDanmaku];
}

- (void)sendDanmaku {
    self.total ++;
    //发送一个弹幕
    RCDDanmaku *danmaku = [[RCDDanmaku alloc]init];
    NSString *str = [self getRandomDanmaku];
    UILabel *label = [[UILabel alloc]init];
    label.attributedText = [[NSAttributedString alloc]initWithString:str attributes:@{NSForegroundColorAttributeName : kRandomColor}];
    [label sizeToFit];
    label.backgroundColor = [UIColor clearColor];
    danmaku.playView = label;
    if(rand()%5==0){
        danmaku.position = RCDDanmakuPositionCenterTop;
    }else if(rand()%7==0)
    {
        danmaku.position = RCDDanmakuPositionCenterBottom;
    }else if(rand()%3==0){
        UIView *backView = [RCDGiftDanmakuView giftDanmakuViewWithText:@"你送出了一个" withImageName:@"clap"];
        danmaku.playView = backView;
    }
    [self.view sendDanmaku:danmaku];
}

- (NSString *)getRandomDanmaku {
    static NSMutableArray *arr = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        arr = [@[@"666",@"前方高能！！！",@"色情主播，我报警了！！！",@"2333",@"111111111111",@"不得不说的事儿",@"笑而不语",@"走过路过不要错过",@"霸业未成！未成啊！",@"这波我服",@"可以，这波很强势",@"菜得抠脚！",@"取消！退订！",@"退订保平安！",@"这波很6",@"妈的智障",@"mdzz",@"卧草6翻了",@"我要报警了",@"这波不亏",@"我想起夕阳下的奔跑",@"那是我逝去的青春",@"我还是太年轻了",@"这么想想我还真有点小激动呢"] mutableCopy];
    });
    
    return arr[arc4random_uniform((u_int32_t)arr.count-1)];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
